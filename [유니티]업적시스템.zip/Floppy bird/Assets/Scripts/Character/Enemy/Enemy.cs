﻿using UnityEngine;
using System.Collections;
using System;


[RequireComponent(typeof(EnemyController))]
[RequireComponent(typeof(WeaponController))]
public class Enemy :Life
{


    public int killScore;              //킬스코어

    public float moveSpeed = 10f;     //이동 속도

        //컨트롤러들
    EnemyController enemyController;
    WeaponController weaponController;


    protected void Awake()        
    {           
        //캐싱
        enemyController = this.GetComponent<EnemyController>();
        weaponController = this.GetComponent<WeaponController>();
    }

    protected void Start()
    {
       
    }

    public override void OnEnable()
    {
       base.OnEnable();        
       StartCoroutine(StartAction());       
    }
    
    protected IEnumerator StartAction()
    {
        
        while (true)
        {
            enemyController.ChangeDirection(new Vector3(-1, 0, 0), moveSpeed);
            while (true)
            {
                yield return new WaitForSeconds(1);
                this.weaponController.Attack();                
            }            
        }       
    }   

    

    public override void Die()
    {
        base.Die();
        //Mediator에서 필요한 함수 실행
        Mediator.SingleTon.WhenEnemyDead(this.gameObject.GetComponent<Enemy>());
       
        //재사용 여부에 따라 Destroy Or Disable
        ObjectPoolingManager.SingleTon.DestroyOrDisable(this.gameObject);
    }

}
