﻿using UnityEngine;
using System.Collections;


//적이 할수 있는 행동 들을 구현, 매개변수를 통해 하나의 함수로 다양 한 행동을 만들수 있도록 구현
public class EnemyController : MonoBehaviour {

   
    Vector3 velocity;
    Rigidbody myRigidbody;

    public float yMax = 10;

    void Awake()
    {
        myRigidbody = this.GetComponent<Rigidbody>();
    }

   
    //제자리에서 멈춤
    public void Stop()
    {      
        velocity = Vector3.zero;
    }       


    //방향과 속력을 바꿈
    public void ChangeDirection(Vector3 direction, float speed)
    {
        velocity = direction.normalized * speed;    
    }
        

    public void FixedUpdate()
    {        
       myRigidbody.MovePosition(myRigidbody.position + velocity * Time.fixedDeltaTime);
      //플레이어의 y축 위치 제한
       myRigidbody.position = new Vector3(myRigidbody.position.x, Mathf.Clamp(myRigidbody.position.y, -yMax, yMax), myRigidbody.position.z);
      
    }

    public IEnumerator Move(Vector3 _velocity, float speed)
    {
        myRigidbody.MovePosition(myRigidbody.position + velocity * Time.fixedDeltaTime);
        //플레이어의 y축 위치 제한
        myRigidbody.position = new Vector3(myRigidbody.position.x, Mathf.Clamp(myRigidbody.position.y, -yMax, yMax), myRigidbody.position.z);
        velocity = _velocity.normalized * speed;
        yield return Time.fixedDeltaTime;
    }



    //타겟을 향해 회전
    //직진
    //대기
    //앞으로 향해 공격
    //타겟을 향해 공격

}
