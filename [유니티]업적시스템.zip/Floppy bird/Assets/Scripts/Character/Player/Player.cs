﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.EventSystems;

[RequireComponent(typeof(PlayerController))]
[RequireComponent(typeof(WeaponController))]
public class Player : Life {

    public float moveSpeed = 10f;         //이동속도


    private int boundaryLayerMask;                    //카메라에서 Boundary를 감지하기 위한 레이어 마스크  
    private float camRayLength = 100.0f;              //화면에서 발사할 Ray(camRay)의 길이    

    private PlayerController playerController;
    private WeaponController weaponController;
    private Vector3 moveInput = new Vector3();

    public static Player SingleTon = null;      //싱글톤    

    protected void Awake()
    {
        if (SingleTon)        //중복방지 - 싱클톤이 이미 있는경우 삭제함
        {
            Destroy(this.gameObject);
            return;
        }
        SingleTon = this;

        //캐싱        
        playerController = this.GetComponent<PlayerController>();
        weaponController = this.GetComponent<WeaponController>();
        boundaryLayerMask = LayerMask.GetMask("Boundary");
        //this.gameObject.AddComponent<Enemy>();
    }

    public override void OnEnable()
    {
        base.OnEnable();
    }


    void Update()
    {
#if UNITY_EDITOR
        //--키보드 입력받기 
        if ((Input.GetKeyUp(KeyCode.W) || Input.GetKeyUp(KeyCode.S)) && !(Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.S)))
            StopMove();
        if (Input.GetKeyDown(KeyCode.W))
            MoveUP();
        if (Input.GetKeyDown(KeyCode.S))
            MoveDown();
#endif

        //입력받은 정보로 최종 속도를 구하고 controller에 전달
        Vector3 moveVelocity = moveInput.normalized * moveSpeed;
        playerController.Move(moveVelocity);


        if (Input.touchCount > 0)
        {
            for (int i = 0; i < Input.touchCount; i++)
            {
                if (Input.GetTouch(i).phase == TouchPhase.Began)
                {
                    //터치 하는 부분에 UI가 없을 경우
                    if (!EventSystem.current.IsPointerOverGameObject(i))
                    {
                        //카메라의 터치위치에서 레이 발사
                        Ray camRay = Camera.main.ScreenPointToRay(Input.touches[i].position);
                        RaycastHit boundaryHit;        //레이가 Boundary에 닿는 위치
                        //화면상에 레이를 쏴서 Boundary에 닫는 벡터를 구함
                        if (Physics.Raycast(camRay, out boundaryHit, camRayLength, boundaryLayerMask))
                        {
                            //플레이어로부터 boundaryHit 방향구하기
                            Vector3 playerToTouch = boundaryHit.point - this.transform.position;
                            // z값 0으로 설정
                            playerToTouch.z = 0f;
                            Attack(Input.touches[i].position);
                        }
                    }
                }
            }
        }



#if UNITY_EDITOR
        //마우스 클릭 = 공격
        if (Input.GetMouseButtonDown(0))
        {
            Attack(Input.mousePosition);
        }


#endif
}


#region MoveFuntion
//가상패드의 버튼 입력 이벤트를 통해 입력
public void MoveUP()
    {
       //padPressed = true;         //패트 터치여부
        moveInput.Set(0, 1, 0);    //방향 설정
    }

    public void MoveDown()
    {
       // padPressed = true;
        moveInput.Set(0, -1, 0);        
    }

    public void StopMove()
    {
      //  padPressed = false;
        moveInput.Set(0, 0, 0);      
    }
    #endregion
    

    //공격
    public void Attack(Vector3 aim )
    {
        Vector3 worldPos;
        worldPos = Camera.main.ScreenToWorldPoint(aim);
        worldPos.z = 0;
        weaponController.Aim(worldPos);
        weaponController.Attack();
    }

    public override void Die()
    {
        base.Die();
        Mediator.SingleTon.WhenPlayerDead();
        Destroy(this.gameObject);
    }



}

