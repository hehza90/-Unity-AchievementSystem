﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;

public class ObjectPoolingManager : MonoBehaviour {

    //큐에있는 모든 객체가 활성화되어 
    //더 이상 활성화시킬 객체가 없을때 어떻게 처리할지 결정
    public enum ExcessHandle     
    {
        //아무런 행동을 하지 않는다
        DONOTMAKE,
        //가장 먼저 활성화됬었던(Queue의 가장 앞) 객체를
        //비활성화 한 후 다시 활성화  
        DEACTIVEFIRST,
        //새로운 객체를 생성하여 풀에 추가
        ADDQUEUE,
        //새로운 객체를 생성 하되 풀에 추가 하지 않음
        DONOTREUSE
    }
        

    //게임오브젝트를 풀링할 갯수와 같은 여러 정보를 가지는 클래스
    [System.Serializable]        //인스펙터뷰에서 편집가능
    public class InfoOfPool
    {
        public string memo;                   //이름    
        public GameObject keyObject;          //대상 오브젝트
        public int poolingNumber;             //풀링할 갯수                
        public ExcessHandle excessHandle;     //풀의 크기 이상의 객체를 생성하려고 할 때 처리 방법               
        [System.NonSerialized]
        public GameObject poolHolder;         //풀링된 오브젝트를 정리하기위한 부모 오브젝트
        //poolingNumber만큼 생성된 keyObject을 저장하는 Pool (Queue로 생성)
        public Queue<GameObject> queuePool = new Queue<GameObject>();
    }

    //인스펙트뷰에서 게임오브젝트와 풀링할 숫자를 편집하기위한 배열, (리스트의 길이 = 게임오브젝트의 종류)
    public List<InfoOfPool> listOfInfo = new List<InfoOfPool>();

    //Key : GameObject , Value : InfoOfPool> 위의 gameObjectStructList 구조체에서 Key와 Value을 얻게됨
    //다른 오브젝트에서 받은 키값(GameObject)으로 그 게임오브젝트가 풀링되어 있는 리스트를 찾음
    private Dictionary<GameObject, InfoOfPool> dicOfInfo = new Dictionary<GameObject, InfoOfPool>();    


    //필요에 의해 인스펙터뷰에 풀링된 갯수보다 초과된 게임오브젝트들을 묶어 놓기위한, ObjectPoolingManager의 자식오브젝트들
    public Transform extendedPool;              //풀이 확장되었을 경우 이 오브젝트의 자식이 됨
    public Transform notReuseObjects;           //재사용하지않는 오브젝트를 생성했을경우 (풀을 확장 시키지 않는 조건에서 요구를 받을때)    

    public static ObjectPoolingManager SingleTon = null;      //싱글톤    
      

    //listOfInfo에서 keyObject와 poolingNumber 로 Dictionary를 만듬
    public void AddDictionary(Dictionary<GameObject, InfoOfPool> dic, InfoOfPool info)
    {
        if (info.keyObject)
        {          
            if (!dic.ContainsKey(info.keyObject))  //키값이 없을경우에만
            {               
                dic.Add(info.keyObject, info);      //gameObjectDic에 Key와 Value지정
                info.poolHolder = new GameObject();
                info.poolHolder.name = info.keyObject.name +" Pool";         //하이어라키뷰에 홀더 생성
                info.poolHolder.transform.parent = this.gameObject.transform; //생성된 오브젝트의 부모를 홀더로
            }                        
        }
    }
      

    //새로운 Pool을 만드는 것과 외부에서 Pool을 늘리는 것을 모두 처리 excessHandle 기본값 DONTREUSE
    public void ObjectPooling (GameObject targetObject, int number=0, ExcessHandle excessHandleWay = ExcessHandle.DONOTREUSE)
    {
        if (targetObject == null)
        {
            return;
        }

        GameObject key = targetObject;
        InfoOfPool targetInfo = dicOfInfo[key];        //오브젝트에대한 정보
        targetInfo.excessHandle = excessHandleWay;     //초과 처리방법 적용
        targetInfo.poolingNumber = number;             //풀크기 설정
        for (int i = targetInfo.queuePool.Count; i < targetInfo.poolingNumber; i++)
        {
            GameObject instatiatedGameObject = (GameObject)Instantiate(targetInfo.keyObject);
            instatiatedGameObject.AddComponent<IsReusing>();            //IsReuing컴포넌트 추가          
            instatiatedGameObject.SetActive(false);     //비활성화            
            targetInfo.queuePool.Enqueue(instatiatedGameObject);   //Pool에 추가            
            instatiatedGameObject.transform.parent = targetInfo.poolHolder.transform;    //홀더의 자식오브젝트로 만듬
        }
    }
        

    //-----------------Awake()--------------------------------
    void Awake()
    {
        if (SingleTon)        //중복방지 - 싱클톤이 이미 있는경우 삭제함
        {
            Destroy(this.gameObject);
            return;
        }
        SingleTon = this;

        //코드 경합을 막기위해 Start()대신 여기에 작성
        for (int i = 0; i < listOfInfo.Count; i++) //인스펙터뷰의 listOfInfo순회
        {
            //사전 생성
            AddDictionary(dicOfInfo, listOfInfo[i]);
            //오브젝트 풀링
            ObjectPooling(listOfInfo[i].keyObject, listOfInfo[i].poolingNumber, listOfInfo[i].excessHandle);
        }
    }
    
    

    //---오브젝트 활성화, 이 함수를 호출할 오브젝트에서 Dictionary에 사용할 Key값과 활성화될 위치,회전 전달
    public void ActiveGameObject(GameObject key, Transform targetTranform)     
    {
        bool activeSucceed = false;                    //생성 성공 여부

        //dictionary에 준 key값이 없을경우 그냥 생성   
        if (!dicOfInfo.ContainsKey(key))
        {
            Instantiate(key, targetTranform.position, targetTranform.rotation);
            activeSucceed = true;
            Debug.Log(key.gameObject.name +" No Dic's Key");     //키값이 없음을 알림
            return;
        }


        InfoOfPool targetInfo = dicOfInfo[key];           //Key로 접근
        GameObject requiredObject = targetInfo.keyObject;
        //requiredObject에는 ObjectPooling함수에서 IsReusing컴포넌트를 얻은 상태

        //dicOfInfo에 키값을 이용해 Queue를 얻음
        Queue<GameObject> requiredQueue = targetInfo.queuePool;
      
   
        
        //큐의 크기만큼 Dequeue 큐를 한번 순회하면서 활성화 여부를 검사
        for (int i = 0; i < requiredQueue.Count; i++)
        {           
            requiredObject = requiredQueue.Dequeue();  //큐의 첫번째요소를 dequeue하여 requiredObject로 참조
            if (requiredObject.activeSelf == false)      //requiredObject가 비활성화상태면 활성화 시킴
            {  
                //위치와 회전 설정후 활성화
                requiredObject.transform.position = targetTranform.position;
                requiredObject.transform.rotation = targetTranform.rotation;
                requiredObject.SetActive(true);
                activeSucceed = true;
            }
            requiredQueue.Enqueue(requiredObject);   //활성화 상태인 requiredObject를 다시 Enqueue

            if (activeSucceed == true)            //활성화가 성공했으므로 루프를 빠져나옴               
                return;
        }

        //activeSucceed가 true이면 비활성화된 객체가 없었으므로 생성에 실패했다는 것이므로
        //어떻게 처리할지 switch문에서 분기해서 결정
        if (activeSucceed == false)
        {
            ExcessHandle handleSwitch = targetInfo.excessHandle;  //Dictionary에 Key값으로 excessHandle값 찾음
          
            switch (handleSwitch)
            {
                case ExcessHandle.DONOTMAKE:                   //생성하지않음                    
                    break;

                case ExcessHandle.DEACTIVEFIRST:               //Queue의 첫번째 요소를 비활성화해서 다시 사용
                    requiredObject = requiredQueue.Dequeue();    //활성화/비활성화 여부에 상관없이 Dequeue
                    requiredObject.SetActive(false);           //그리고 비활성화하므로 게임에서 사라짐
                    //위치와 회전 재설정
                    requiredObject.transform.position = targetTranform.position;
                    requiredObject.transform.rotation = targetTranform.rotation;
                    requiredObject.SetActive(true);
                    requiredQueue.Enqueue(requiredObject);      //큐에 다시 추가                    
                    break;

                case ExcessHandle.ADDQUEUE:   //새로운 객체를 생성하여 Queue에 추가, 정확하게는 풀에있는 객체를 복사해서 추가
                    //객체생성                    
                    GameObject addObject = (GameObject)Instantiate(requiredObject, targetTranform.position, targetTranform.rotation);                    
                    requiredQueue.Enqueue(addObject);                      //Queue에 추가                    
                    addObject.transform.name = requiredObject.name;        //이름 설정  
                    addObject.transform.parent = extendedPool;   //부모오브젝트 설정
                    targetInfo.poolingNumber++;     
                    break;

                case ExcessHandle.DONOTREUSE:                //새로운 객체를 생성하여 재사용여부를 false로 지정
                    //객체생성
                    GameObject instantiateObject = (GameObject)Instantiate(key, targetTranform.position, targetTranform.rotation);                                        
                    instantiateObject.transform.name = requiredObject.name;        //이름 설정  
                    instantiateObject.transform.parent = notReuseObjects;   //부모오브젝트 설정                 
                    break;
            }
            //어떤 오브젝트가 활성화에 실패했는지, 어떻게 처리했는지 콘솔창에 표시
            Debug.Log("'" + key.name+ "'"+" Activate Fail "  + "'"+ handleSwitch + "'"); 
        }
    }


    //풀의 크기 줄이기
    public void ReducePool(GameObject key, int amount)
    {
        InfoOfPool infoOfPool = dicOfInfo[key];
        infoOfPool.poolingNumber -= amount;

        for (int i = infoOfPool.queuePool.Count; i > infoOfPool.poolingNumber; i--)
        {
            if (infoOfPool.queuePool.Count <= 0) //풀이 없는경우 return
            {
                return;
            }
            GameObject dequeueObject = infoOfPool.queuePool.Dequeue();  //pool에서 제거
            //이미 비활성화 상태라면 파괴
            if (dequeueObject.activeSelf == false)
            {
                Destroy(dequeueObject);
            }
            else   //아니라면 IsReusing컴포넌트 제거
            {
                Destroy(dequeueObject.GetComponent<IsReusing>());
            }    
        }
    }


    //재사용여부를 확인하여 비활성화 시키거나 파괴할지 결정
    public void DestroyOrDisable(GameObject target)
    {
        IsReusing IsReusingScript;
        //IsReusing 컴포넌트가 있는지 확인
        IsReusingScript = target.GetComponent<IsReusing>();
        if (IsReusingScript == null) {          //IsReusing==true면 비활성화          
            Destroy(target.gameObject);
        }
        else
            target.SetActive(false);        
    }

}
