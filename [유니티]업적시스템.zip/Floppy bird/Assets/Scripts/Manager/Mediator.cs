﻿using UnityEngine;
using System.Collections;
using System;

public class Mediator : MonoBehaviour {

    public static Mediator SingleTon = null;      //싱글톤  

    //----------------Awake()----------------
    void Awake()
    {
        if (SingleTon)        //중복방지 - 싱클톤이 이미 있는경우 삭제함
        {
            Destroy(this.gameObject);
            return;
        }
        SingleTon = this;
        DontDestroyOnLoad(this.gameObject);     //씬이 넘어가도 유지
    }
    
    public void WhenPlayerDead() {
        GameManager.SingleTon.GameOver();
    }


    //Enemy가 죽었을때 DeathEvent에 필요한 여러함수 실행
    public void WhenEnemyDead(Enemy deadEnemy)
    {
        //ScoreManger에서 Enemy에 지정된 스코어 만큼 스코어를 올리는 함수
        ScoreManger.SingleTon.GetEnemyScore(deadEnemy);
        //AchievementManager의 적 처치횟수을 세는 함수
        AchievementManager.SingleTon.CountTotalEnemyKillCount();
    } 
}
