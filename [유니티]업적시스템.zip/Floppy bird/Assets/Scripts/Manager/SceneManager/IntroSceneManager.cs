﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;


public class IntroSceneManager : MonoBehaviour {

    public static IntroSceneManager SingleTon = null;

    void Awake()
    {
        if (SingleTon)        //중복방지 - 싱클톤이 이미 있는경우 삭제함
        {
            Destroy(this.gameObject);
            return;
        }
        SingleTon = this;
    }


    public void GameStart()
    {
        SceneManager.LoadScene("TestScene", LoadSceneMode.Single);
        SceneManager.LoadScene("AchievementSystem", LoadSceneMode.Additive);
    }

    public void OpenAchievement()
    {
   
        AchievementManager.SingleTon.OpenAndClose();
    }


}
