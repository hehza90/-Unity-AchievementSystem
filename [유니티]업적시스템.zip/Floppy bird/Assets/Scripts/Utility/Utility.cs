﻿using UnityEngine;
using System.Collections;

public class Utility : MonoBehaviour
{
    //오브젝트가 특정지점을 바라보게하는 함수
    public static void Aim(Transform aimObject, Vector3 targetVector)
    {
       Quaternion aim;
       Vector3 objectToVector = targetVector - aimObject.position;
        aim = Quaternion.LookRotation(objectToVector);  //aim 은 플레이어와 마우스 사이의 회전값
        aimObject.rotation = aim;                      //bullet이 생성되는 위치       
    }
}