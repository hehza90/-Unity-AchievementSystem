﻿using UnityEngine;
using System.Collections;

public class Projectile : MonoBehaviour
{

    public float damage = 10f;                       //데미지
    public float speed = 20f;                  //나아가는 속도


    private Vector3 velocity;

    private Rigidbody bulletRigidbody;

    
    void Awake()
    {
        bulletRigidbody = GetComponent<Rigidbody>();
    }

    public void OnEnable()
    {       
        ChangeDirection(this.transform.forward, speed);
    }

    public void ChangeDirection(Vector3 direction, float _speed)
    {
        velocity = direction.normalized * _speed;
    }


    //--------FixedUpdate()-------------
    public void FixedUpdate()
    {
        bulletRigidbody.MovePosition(bulletRigidbody.position + velocity * Time.fixedDeltaTime);
    }  



    //충돌
    protected void OnTriggerEnter(Collider coll)
    {
        IDamageable damegeable= coll.GetComponent<IDamageable>();  //데미지를 줄수 있는 대상인지 검사
        if (damegeable!= null){            
            damegeable.TakeDamage(this.damage);
            ObjectPoolingManager.SingleTon.DestroyOrDisable(this.gameObject);
            
        }
    }
    

    //------------OnDisable()------------------
    public void OnDisable()
    {
    }
    

}
