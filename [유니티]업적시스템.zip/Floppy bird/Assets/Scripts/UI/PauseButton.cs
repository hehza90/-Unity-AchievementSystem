﻿using UnityEngine;
using System.Collections;

public class PauseButton : MonoBehaviour {

    float currentTimeScale;
    public GameObject pauseMenu;
    bool stopped = false;

    public static PauseButton SingleTon = null;

    void Awake()
    {
        if (SingleTon)        //중복방지 - 싱클톤이 이미 있는경우 삭제함
        {
            Destroy(this.gameObject);
            return;
        }
        SingleTon = this;
    }

    void Start()
    {
        currentTimeScale = Time.timeScale;
        pauseMenu.SetActive(false);
    }


    public void Pressed()
    {
        //게임재게
        if (stopped ==true)   //멈춘상태에서 눌러졌을때
        {
            stopped = false;
            Time.timeScale = currentTimeScale;           
            pauseMenu.SetActive(false);
        }
        //게임 일시정지
        else
        {
            stopped = true;
            Time.timeScale = 0;          
            pauseMenu.SetActive(true);
        }
    }
}