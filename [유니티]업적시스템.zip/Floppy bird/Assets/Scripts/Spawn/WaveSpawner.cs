﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;


//다음 웨이브가 시작되는 시점은 이전웨이브가 시작되는 시점으로부터 nextWaveTime가 지난 시점
public class WaveSpawner : MonoBehaviour {

    public float startTime;               //스폰 시작시간
    public GameObject spawnPointsParent;   //씬뷰의 SpawnPoint들의 부모 객체
    public Transform[] spawnPoints;         //SpawnPoint, 생성되는 위치


    [System.Serializable]
    public class Wave { 
    
        public string Memo;
        public GameObject spawnObject;       //생성시킬 객체
        public int spawnCount;               //생성할 수

        public bool isRandomPosition;      //생성위치를 랜덤으로 설정, 값이 true라면 밑의 spawnPosition에 할당된 값은 무시됨
        public Transform spawnPosition;    //지정하지 않을 경우 랜덤
        public float spawnRate;            //스폰 주기
        public float nextWaveTime;         //현재 웨이브가 시작한 후 부터 다음 웨이브 시작까지 시간 간격
    }                                       //값이 0일경우 동시에 웨이브 시작

    
    public List<Wave> waveList;         //인스펙터뷰에서 웨이브 편집

    
    void Start()
    {
        //씬의 모든 스폰포인트를 찾음, 단 배열의 첫번째요소는 SpawnPointParent이므로 사용하지 않음
        spawnPoints = spawnPointsParent.GetComponentsInChildren<Transform>();
        StartCoroutine(StartSpawn());        //스폰시작
    }


    IEnumerator StartSpawn()
    {
        yield return new WaitForSeconds(startTime);    //시작시간만큼 대기후 시작
        for (int i=0; i< waveList.Count; i++)
        {
            StartCoroutine(SpawnWave(waveList[i]));         //웨이브 시작
            
            yield return new WaitForSeconds(waveList[i].nextWaveTime);  //다음 웨이브까지 대기          
        }
        yield return null;
    }


    IEnumerator SpawnWave(Wave targetWave)
    {
        for (int i = 0; i < targetWave.spawnCount; i++)   //적의 수만큼 반복
        {
            if(targetWave.isRandomPosition)  //스폰위치가 랜덤일 경우
            {
                //배열의 첫번째요소는 SpawnPointParent이므로 사용하지 않음
                targetWave.spawnPosition = spawnPoints[Random.Range(1,spawnPoints.Length)];
            }
                                        
            ObjectPoolingManager.SingleTon.ActiveGameObject(targetWave.spawnObject, targetWave.spawnPosition); //생성
            yield return new WaitForSeconds(targetWave.spawnRate);   //다음 스폰까지 대기
        }
        yield return null;
    }


}

