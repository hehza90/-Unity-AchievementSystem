﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System.Collections.Generic;
using System;



//데이터 저장
//각 이벤트에 등록된 업적들에게 알림
//업적 해금
public class AchievementManager : MonoBehaviour {

    [NonSerialized]
    public int totalAchievementPoint=0;   

    public GameObject achievementWindow;            //업적창 전체

    public GameObject categoryArea;               //카테고리 버튼들이 생기는 영역

    public Text totalAchievementPointText;           //전체 업적 점수
    
    public ScrollRect scrollRect;                  //스크롤

    public GameObject unlockShowingArea;           //업적완료시 게임 화면에 알림
    [System.NonSerialized]
    public CategoryButton selectedButton;             //현제 선택된 버튼

    //---Achievemet의 일괄적인 이미지
    //public Sprite backGroundImage;    //배경 이미지
    public Sprite unlockedImage;               //업적이 언락되었을때 바꿀 이미지
    public float showingFadeTime;              //업적 언락 알림 메세지가 다시 사라지는 시간
        

    //업적 데이터 & 알림 이벤트
    #region AchievementData     



    // KillEnemy카테고리 - 적 처치횟수에 따른 업적을 다룸
    #region TotalKillEnemy      
         
    [System.NonSerialized]
    public int TotalEnemyKill=0;     //데이터 - 전체 적 처치 수
    public event Action NotifyAnyEnemyKilled;  //데이터가 갱신 될때 특정 Achievement에 알림

    public void CountTotalEnemyKillCount()     //데이터를 갱신하고 NoifyAnyEnemyKilld();
    {
        TotalEnemyKill++;
        PlayerPrefs.SetInt("TotalEnemtKill", TotalEnemyKill);  //데이터 갱신
        if (NotifyAnyEnemyKilled!= null)
        {
            NotifyAnyEnemyKilled();          //업적들에게 알림
        }
    }
    #endregion TotalKillEnemy
    



    #endregion AchievemetData


    public static AchievementManager SingleTon = null;

    //-----------------Awake()-----------------
    private void Awake()
    {
        if (SingleTon)        //중복방지 - 싱클톤이 이미 있는경우 삭제함
        {
            Destroy(this.gameObject);
            return;
        }
        SingleTon = this;

        //PlayerPrefs 에서 데이더 불러오기
        //totalAchievementPoint = PlayerPrefs.GetInt("TotalAchievementPoint");
        //TotalEnemyKill = PlayerPrefs.GetInt("TotalEnemtKill");
        PlayerPrefs.DeleteAll();  //테스트용 초기화
    }

    //-------------------Start()------------------
    private void Start()
    {
        //카테고리 버튼 목록 시작시 첫 카태고리버튼 선택(일회성)
        CategoryButton categoryList= categoryArea.GetComponentInChildren<CategoryButton>();            
        ChangeCategory(categoryList);
        OpenAndClose();
    }


    //전체업적점수 갱신
    public void renewTotalAchievementPoint(int point) 
    {
        totalAchievementPoint += point;
        //PlayerPrefs.SetInt("TotalAchievementPoint", totalAchievementPoint);
        totalAchievementPointText.text ="Total : "+ totalAchievementPoint.ToString();
    }




    //--------------Update()----------------------
    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.I))
        {
            OpenAndClose();
        }
    }

    //창 열고 닫기
    public void OpenAndClose()
    {
        achievementWindow.SetActive(!achievementWindow.activeSelf);
    }

    ////업적이 달성됨을 알림
    public void ShowUnlockAchievement(Achievement unlockedAchievement)
    {
        Achievement showingAchievement = Instantiate(unlockedAchievement);  //언락된 업적을 복제
        showingAchievement.unlocked = 1;
        showingAchievement.GetComponent<Image>().sprite = unlockedImage;
        showingAchievement.transform.SetParent(unlockShowingArea.transform);
        showingAchievement.transform.localScale = new Vector3(1, 1, 1);     
          
        StartCoroutine(FadeInAndOutAchievement(showingAchievement));  
    }


    //업적알림 페이드 인/아웃
    private IEnumerator FadeInAndOutAchievement(Achievement showingAchievement)
    {
        CanvasGroup canvasGroup = showingAchievement.GetComponent<CanvasGroup>();

        float rate = 1.0f / showingFadeTime;
        int startAlpha = 0;
        int endAlpha = 1;

        //i가 0일때 알파값 0 에서1
        //i가 1일때 알파값 1 에서0
        for (int i=0; i<2; i++)
        {
            float progress = 0.0f;

            while (progress < 1.0f)
            {
                canvasGroup.alpha = Mathf.Lerp(startAlpha, endAlpha, progress);
                progress += rate * Time.deltaTime;
                yield return null;
            }
            yield return new WaitForSeconds(2);
            startAlpha = 1;
            endAlpha = 0;
        }

        Destroy(showingAchievement);
    }
   

    //카테고리 버튼클릭시 기존의 카테고리의 리스트를 닫고 다른 카테고리의 업적 리스트 활성화
    public void ChangeCategory(CategoryButton button)
    {
        CategoryButton clickedButton = button;       //유저가 클릭한 버튼

        if (clickedButton.achievementListArea!= null)
        {
            //스크롤를 통해 움직이는 content를 해당 버튼의 업적리스트에 연결
            scrollRect.content = clickedButton.achievementListArea.GetComponent<RectTransform>();
        }
        else      //연결되어 있는 리스트가 없다면
        {
            scrollRect.content = null;
        }
         

        clickedButton.Click();          //버튼 클릭 - SELECTED(선택된 상태)로
        if (selectedButton != null)      //이전에 선택되어 있는 버튼이 있다면
        {
            selectedButton.Click();      //기존 버튼 클릭 - NORMAL(선택이 해제된 상태)로
        }        
        selectedButton = clickedButton;      //selectedButton 갱신
    }

}
