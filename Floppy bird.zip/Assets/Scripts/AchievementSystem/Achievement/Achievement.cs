﻿using UnityEngine;
using UnityEngine.UI;
using System;

//이 클래스를 상속 해서 사용
public class Achievement : MonoBehaviour{

    public int Goal;        //목표수

    [NonSerialized]
    public int progress;   //진척도

    public int point;         //업적 달성시 포인트

   [NonSerialized]
    public int unlocked = 0;         //언락 여부(0 : 락 1: 언락)

    public event Action NotifyThisUnlock;     //이 업적이 언락되었을때 실행할 이벤트

  

    //-----------Awake()-----------------
    protected virtual void Awake()
    {
        if (unlocked==1)  //언락 상태라면
        {
            //이미지를 Unlock된 이미지로 교체
           this.gameObject.GetComponent<Image>().sprite = AchievementManager.SingleTon.unlockedImage;
        }
        //텍스트를 포인트에 맞게 변경
        this.gameObject.transform.Find("Points").GetComponent<Text>().text = point.ToString();
    }
        

    //진척상황 갱신
    public virtual void RenewProgress() { }

    //업적 완료
    public void UnlockAchievement()
    {        
        if (unlocked==0)         //언락이 아닐시에만 동작
        {
            unlocked = 1;
            //언락 이벤트실행
            if (NotifyThisUnlock != null)
            {
                NotifyThisUnlock();
            }      
            //전체 업적 점수 갱신
            AchievementManager.SingleTon.renewTotalAchievementPoint(point);
            //이미지를 Unlock된 이미지로 교체
            this.gameObject.GetComponent<Image>().sprite = AchievementManager.SingleTon.unlockedImage;
            //업적 달성 알림
            AchievementManager.SingleTon.ShowUnlockAchievement(this);
        }     
    }

}
