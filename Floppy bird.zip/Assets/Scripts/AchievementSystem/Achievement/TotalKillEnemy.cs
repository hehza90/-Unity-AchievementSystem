﻿using UnityEngine;
using System;

public class TotalKillEnemy : Achievement { 
       
    //-----------Awake()-----------------
    protected override void Awake()
    { 
        //키값이 없다면 키 생성
        if (PlayerPrefs.HasKey("IsUnlock_TotalkillEnemy") == false)
        {
            PlayerPrefs.SetInt("IsUnlock_TotalkillEnemy", 0);
        }

        //언락여부 정보 가져오기
        //unlocked = PlayerPrefs.GetInt("IsUnlock_TotalkillEnemy");
        base.Awake();
        if (unlocked == 0)    //언락이 안되어 있을때만
        {
            //원하는 데이터를 다루는 곳에 이벤트 등록
            AchievementManager.SingleTon.NotifyAnyEnemyKilled += () => RenewProgress();
        }        
    }
    
    //진척상황 초기화
    public override void RenewProgress()
    {
        if (unlocked == 0)     //언락이 안되어 있을때만
        {
            progress = AchievementManager.SingleTon.TotalEnemyKill;   //진척도 적용
                        
            if (progress >= Goal)       //골 달성시
            {                
                //업적언락
                base.UnlockAchievement();
               // PlayerPrefs.SetInt("IsUnlock_TotalkillEnemy", unlocked);
                //이벤트 구독 해지
                AchievementManager.SingleTon.NotifyAnyEnemyKilled -= () => RenewProgress();
            }

        }                
    }

}