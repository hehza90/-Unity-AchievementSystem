﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System;

public class CategoryButton : MonoBehaviour {

    public enum ButtonState   //버튼의 상태
    {
        NORMAL, SELECTED
    }

    [SerializeField]
    public Text buttonText;                 //버튼의 텍스트 입력된 이름 참조        
    public GameObject achievementListArea;   //업적들이 표시되는 곳
    public Sprite neutral, selected;         //버튼의 상태에 따른 이미지
  
    private Image buttonImage;               //이미지
    public ButtonState currentState;         //버튼의 현제 상태

    



    //------------Awake()-----------------
    void Awake()
    {
       buttonImage = GetComponent<Image>();
    }



    void Start()
    { 
        currentState = ButtonState.NORMAL;         //버튼상태 =NORMAL
        if (achievementListArea!=null)
        {
            achievementListArea.SetActive(false);        //업적 리스트 비활성화
        }                        
        //categoryName = this.gameObject.name;        //카테고리의 이름을 하이어라키뷰의 이름으로 설정
        if (buttonText != null)
        {
            buttonText.text = this.gameObject.name;    //버튼의 텍스트 설정
        }        
       // achievementListArea.name = this.gameObject.name;   //연결된 리스트의 이름을 '카테고리이름' List로
    }  

    //버튼을 클릭했을때
    public void Click()
    {
        switch (currentState)
        {
            case ButtonState.NORMAL:                    
                currentState = ButtonState.SELECTED;     // SELECTED로 전환
                buttonImage.sprite = selected;           //이미지 전환
         
                if (achievementListArea == null)
                {
                    break;
                }
                achievementListArea.SetActive(true);      //업적리스트 보여주기
                break;

            case ButtonState.SELECTED:
                currentState = ButtonState.NORMAL;          // NORMAL로 전환
                buttonImage.sprite = neutral;             //이미지 전환                

                if (achievementListArea == null)
                {
                    break;
                }
                achievementListArea.SetActive(false);      //업적리스트 가리기
                break;
        }
    }
 
}
