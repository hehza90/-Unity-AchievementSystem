﻿using UnityEngine;
using System.Collections;



//플레이어를 검색해 가상패드와 연결
public class ConnectToPlayer : MonoBehaviour {


    Player player;

	void Awake()
    {   //플레이어를 검색해서 컴포넌트 캐싱
        player = GameObject.FindGameObjectWithTag("Player").GetComponent<Player>();
    }


    public void MoveUp()
    {
        player.MoveUP();
    }

    public void MoveDown()
    {
        player.MoveDown();
    }

    public void StopMove()
    {
        player.StopMove();
    }

}
