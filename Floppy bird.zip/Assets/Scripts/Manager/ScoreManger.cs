﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using System;

public class ScoreManger : MonoBehaviour
{  
    public Text textScore;
    public int totalScore = 0;


    public static ScoreManger SingleTon = null;

    //-----------------Awake()--------------------------------
    void Awake()
    {
        if (SingleTon)        //중복방지 - 싱클톤이 이미 있는경우 삭제함
        {
            Destroy(this.gameObject);
            return;
        }
        SingleTon = this;        
    }



    //-------------------Start()------------------
    void Start()
    {
        renewScore();
    }



    public void GetEnemyScore(Enemy enemy)
    {
        AddScore(enemy.killScore);
    }

    public void AddScore(int i)
    {
        totalScore += i;
        renewScore();
    }    
 

    //화면 표시
    public void renewScore()
    {        
        textScore.text = "SCORE " + totalScore.ToString();  
    }
    
}
