﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour {

   [NonSerialized] 
   public bool isGameOver = false;       //GameOver 플래그
    
    //GameManager 싱글톤 생성
    public static GameManager SingleTon=null;

    void Awake()
    {
        if (SingleTon)        //중복방지 - 싱클톤이 이미 있는경우 삭제함
        {            
            Destroy(this.gameObject);
            return;
        }
        SingleTon = this;

        DontDestroyOnLoad(this.gameObject);
        //업적시스템은 항상 로드되어있는 상태
        SceneManager.LoadScene("AchievementSystem", LoadSceneMode.Additive);  
    }



    public void GameOver()   //GameOver시
    {
        SceneManager.LoadScene("GameOverScene", LoadSceneMode.Additive);
        PauseButton.SingleTon.gameObject.SetActive(false);
    }
    

}
