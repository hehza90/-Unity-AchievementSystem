﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class GameOverSceneManager : MonoBehaviour {
    
    public static GameOverSceneManager SingleTon = null;

    void Awake()
    {
        if (SingleTon)        //중복방지 - 싱클톤이 이미 있는경우 삭제함
        {
            Destroy(this.gameObject);
            return;
        }
        SingleTon = this;
    }



    //재시작
    public void Restart()
    {
        SceneManager.LoadScene("TestScene", LoadSceneMode.Single);
        SceneManager.LoadScene("AchievementSystem", LoadSceneMode.Additive);
    }

    //메인메뉴로
    public void MainMenu ()
    {
        SceneManager.LoadScene("IntroScene", LoadSceneMode.Single);
        SceneManager.LoadScene("AchievementSystem", LoadSceneMode.Additive);
    }
}
