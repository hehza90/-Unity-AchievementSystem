﻿using UnityEngine;
using System.Collections;

public class Weapon : MonoBehaviour
{
    public GameObject projectile;   //공격시 생성할 객체
    public Transform attackPoint;   //Projectile 생성 지점
    public float attackRate=0;       //공격 주기

    private float nextAttack;    //다음 공격이 가능한 시간
   

    //프로젝타일 만들기
    public void MakeProjectile()
    {
        if (Time.time > nextAttack)
        {        
            nextAttack = Time.time + attackRate;
            ObjectPoolingManager.SingleTon.ActiveGameObject(projectile, attackPoint);
        }            
    }

}
