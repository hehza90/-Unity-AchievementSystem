﻿using UnityEngine;
using System.Collections;


public class WeaponController : MonoBehaviour {

    public Transform weaponHold;   //Prefab할당      
    public Weapon equippedWeapon;
    public Weapon startingWeapon;   //플레이어용

    
    void Start()
    {
        if (startingWeapon != null)
        {
            EquipWeapon(startingWeapon);
        }
    }


    public void EquipWeapon(Weapon weaponToEquip)              //플레이어용
    {
        if (equippedWeapon != null)
        {
            Destroy(equippedWeapon.gameObject);
        }
        equippedWeapon = Instantiate(weaponToEquip, weaponHold.position, weaponHold.rotation) as Weapon;
        equippedWeapon.transform.parent = weaponHold;
    }

    public void Aim(Vector3 targetVector)   //weaponHold을 타겟지점을 향하게 만듬
    {
        Quaternion aim;                                         //회전해야할 값
        Vector3 objectToVector = targetVector - weaponHold.position;  //aim weaponHold와 목표지점의 벡터값
        aim = Quaternion.LookRotation(objectToVector);     //회전 값 구하기
        weaponHold.rotation = aim;                        //WeaponHold 회전      
    }


    public void Attack()
    {       
        if (equippedWeapon != null)
        {
            equippedWeapon.MakeProjectile();
        }
    }
    
   /*public IEnumerator CoAttack()
    {
        if (equippedWeapon != null)
        {          
            equippedWeapon.MakeProjectile();
        }
        yield return new WaitForSeconds(1);
    }*/



}
