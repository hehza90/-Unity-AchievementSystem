﻿using UnityEngine;
using System.Collections;


[RequireComponent(typeof(Rigidbody))]
public class PlayerController : MonoBehaviour
{
    Vector3 velocity;
    Rigidbody myRigidbody;
    public float yMax = 12;


    void Awake()
    {
        myRigidbody = GetComponent<Rigidbody>();
    }

    public void Move(Vector3 _velocity)
    {
        velocity = _velocity;
    }

    
    public void FixedUpdate()
    {
        myRigidbody.MovePosition(myRigidbody.position + velocity * Time.fixedDeltaTime);
        //플레이어의 y축 위치 제한
        myRigidbody.position = new Vector3(myRigidbody.position.x, Mathf.Clamp(myRigidbody.position.y, -yMax, yMax), myRigidbody.position.z);
    }

}